#!/bin/bash

PYTHONPATH=$HOME/nestml-fork-integrate_specific_odes:$PYTHONPATH python3 generate_nestml_model_code.py
