source /p/home/jusers/linssen1/jusuf/nest-simulator-install/bin/nest_vars.sh
