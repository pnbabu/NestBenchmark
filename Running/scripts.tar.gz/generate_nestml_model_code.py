#!/usr/bin/env python3
#
# -*- coding: utf-8 -*-

from pynestml.frontend.pynestml_frontend import generate_nest_target

generate_nest_target(input_path="/p/home/jusers/linssen1/jusuf/nestml-fork-integrate_specific_odes/models/neurons/iaf_psc_alpha_neuron.nestml",
                     suffix="_Nestml",
                        logging_level="DEBUG")

